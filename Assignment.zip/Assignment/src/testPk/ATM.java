package testPk;

import java.util.Scanner;

class ATMTransaction
{
	int deposit(int a,int b)
	{
		return a+b;
	}
	int withdraw(int a,int b)
	{
		return a-b;
	}
}
public class ATM 
{
	
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your current balance");
		
		int a=sc.nextInt();
		System.out.println("Enter amount you want to deposit");
		
		int b=sc.nextInt();
		ATMTransaction addobj=new ATMTransaction();
		int ADD=addobj.deposit(a,b);
		System.out.println("money deposited:"+ADD);
	
		Scanner s= new Scanner(System.in);
		System.out.println("Enter your current balance");
		
		int d=s.nextInt();
		System.out.println("Enter amount you want to withdraw");
		
		int e=s.nextInt();
		ATMTransaction subobj=new ATMTransaction();
		int SUB=subobj.withdraw(a,b);
		System.out.println("money withdrawed:"+SUB);
	            
	}
}
	
