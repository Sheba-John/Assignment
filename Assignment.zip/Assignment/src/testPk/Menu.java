package testPk;

import java.util.Scanner;
class Menu1 
{
	int pizza(int a)
	{
		return a;
	}
	int burger(int b)
	{
		return b;
	}
	int coldrink(int c)
	{
		return c;
	}
	int tea(int d)
	{
		return d;
	}
	double Balance(int e)
	{
		return 10/100*e;
	}
}

public class Menu {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        while(true)
        {
        	System.out.println("Choose 1 for 2 Pizza");
        	System.out.println("Choose 2 for 4 burger");
        	System.out.println("Choose 3 for 7 coldrink");
        	System.out.println("Choose 4 for tea");
            System.out.println("Choose 5 for bill amount more than 500-1000");
            System.out.println("Choose 6 for exit");
            System.out.print("Choose the operation you want to perform:");
            int n = s.nextInt();
            switch(n)
            {
            case 1:
		Menu1 ee=new Menu1();
		int Cost=ee.pizza(250);
		System.out.println("Cost of two pizzas is:"+Cost);
		break;
		
            case 2:
		Menu1 mm=new Menu1();
		int Price=mm.burger(300);
		System.out.println("Cost of four burger is:"+Price);
		break;
		
            case 3:
		Menu1 rr=new Menu1();
		int Rate=rr.coldrink(200);
		System.out.println("Cost of 7 cold drink is:"+Rate);
		break;
		
            case 4:
		Menu1 ss=new Menu1();
		int Sell=ss.burger(50);
		System.out.println("Cost of tea is:"+Sell);
		break;
		
                case 5:
                	Menu1 tt=new Menu1();
                	double tot=tt.Balance(3000);
                System.out.print("Total bill Amount:"+tot);
              break;
             
                case 6:
                    System.exit(0);
            }
        }
	}
}
		
		
		
