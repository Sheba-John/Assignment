package testPk;
import java.util.Scanner;
public class AgesScanner {

	public static void main(String[] args) {
		System.out.print("Enter the Age: ");
		Scanner in = new Scanner(System.in);
		int i = in.nextInt();
		in.close();
		if (i >= 0 && i <= 5) {
			System.out.println("Giselle");
		} else if (i >= 6 && i <= 18) {
			System.out.println("Erica");
		} else if (i >= 20) {
			System.out.println("Sheba");
		} else {
			System.out.println("Invalid input");
		}
	}
}
