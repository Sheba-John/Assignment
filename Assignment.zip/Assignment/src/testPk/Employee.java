package testPk;

class Emp1 
{
	int Travel(int a)
	{
		return a;
	}
	int dear(int b)
	{
		return b;
	}
	int HRA(int c)
	{
		return c;
	}
	int Basic(int d)
	{
		return d;
	}
	int salary(int a, int b, int c, int d)
	{
		return a+b+c+d;
	}
}

public class Employee {
	
	public static void main(String[] args) {
		
		Emp1 ee=new Emp1();
		int Sal=ee.Travel(2000);
		System.out.println("Travel allowance of Employee:"+Sal);
		
		Emp1 add=new Emp1();
		int ADD=add.dear(1000);
		System.out.println("Dear allowance of Employee:"+ADD);
		
		Emp1 aa=new Emp1();
		int VAL=aa.HRA(3000);
		System.out.println("house allowance of Employee:"+VAL);
		
		Emp1 bb=new Emp1();
		int Basic=bb.HRA(3000);
		System.out.println("Basic Salary of Employee:"+Basic);
		
		
		Emp1 ss=new Emp1();
		int TOT=ss.salary(2000,1000,3000,10000);
		System.out.println("Total Salary of Employee:"+TOT);
		
}
}
