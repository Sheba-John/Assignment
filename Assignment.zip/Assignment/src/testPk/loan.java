package testPk;
import java.util.Scanner;
class loans
{
	int a;
	double g;
	
	Scanner input = new Scanner(System.in);
	loans()
    {
    	System.out.println("Enter loan amount:");
    	a = input.nextInt();
    	
    	System.out.println("Enter ROI:");
    	g = input.nextDouble();
    	
    }
 
    void display()
    {
    	System.out.println("loan amount: "+a);
    	System.out.println("ROI: "+g);
        
    }
}


class Amount extends loans
{
	
	{   double t,ci;
	
	
  
     ci = a*(Math.pow((1 + g / 100), 2.5));
               
    System.out.println("Compound Interest  is: " +ci);  
}}  



public class loan {

	public static void main(String[] args) {
		System.out.println("================================"+"\n"+"Enter Amount details"+"\n"+"================================"+"\n");
        Amount ob1 = new Amount();
        
     
        
        ob1.display();
       
       

	}

}

