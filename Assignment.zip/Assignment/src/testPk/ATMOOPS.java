package testPk;

import java.util.Scanner;

class  Transaction
{
	int addition(int a, int b)
	{
		return a+b;
	}
	int substraction(int a, int b)
	{
	return a-b;
	}
}
public class ATMOOPS {
public static void main(String[] args)
{
	Transaction addobj=new Transaction();
	int ADD=addobj.addition(1000, 2000);
Scanner s = new Scanner(System.in);
System.out.println("Choose 1 for Withdraw");
System.out.println("Choose 2 for Deposit");
int n = s.nextInt();
2
System.out.println("money to be deposited"+ADD);
}
}
