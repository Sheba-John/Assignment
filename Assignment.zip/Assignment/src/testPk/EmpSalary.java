package testPk;
import java.util.Scanner;
class Employee
{
	int a;
	String g;
	
	Scanner input = new Scanner(System.in);
	Employee()
    {
    	System.out.println("Enter Salary:");
    	a = input.nextInt();
    	
    	System.out.println("Enter Name of Employee:");
    	 g = input.next();
    	
    }
    void display()
    {
        System.out.println("Enter Salary: "+a);
        
    }
 
   
}
 
class fullTimeEmployees extends Employee
{
	int b;
	{
	if (a==50000)
	{
	b=(a*10)/100;
	System.out.println("Bonus Applicable :"+b);
	}
	else
	{
	if(a==40000)
	{
	b=(a*20)/100;
	System.out.println("Bonus Applicable :"+b);
	}
	else
	{
	if(a==60000)
	{
	b=(a*5)/100;
	System.out.println("Bonus Applicable :"+b);
	}
	else
	System.out.println("No Bonus");
	}
}
	}
}
	
 
public class EmpSalary
{
    public static void main(String args[])
    {
        System.out.println("================================"+"\n"+"Enter Full Time Employee Details"+"\n"+"================================"+"\n");
        fullTimeEmployees ob1 = new fullTimeEmployees();
        
        ob1.display();
        
    
    }
}
	
