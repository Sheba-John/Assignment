package testPk;
import java.util.Scanner;
class Banks
{
	String name;
    Scanner get = new Scanner(System.in);
    Banks()
    {
        System.out.println("Enter Name of the Bank:");
        name = get.nextLine();
        
        
    }
 
    void display()
    {
        System.out.println("Bank Name: "+name);
        
    }
}


class B1 extends Banks
{
	
	{   double p,r,  t,  si;
	
    p = 13000;  r = 10.05; t = 2;  
     si  = (p*r*t)/100;   
    System.out.println("Simple Interest for SBI Bank is: " +si);  
}}  

class B2 extends Banks
{
{   double p,r,  t,  si;
	
    p = 13000;  r = 9.05; t = 2;  
     si  = (p*r*t)/100;   
    System.out.println("Simple Interest for Axis Bank is: " +si);  
}}  
	
class B3 extends Banks
{
{   double p,r,  t,  si;
	
    p = 13000;  r = 8.05; t = 2;  
     si  = (p*r*t)/100;   
    System.out.println("Simple Interest for Bank of Baroda is: " +si);  
}}  

public class Bank {

	public static void main(String[] args) {
		System.out.println("Enter B1 details");
        B1 ob1 = new B1();
        
        System.out.println("================================"+"\n"+"Enter B2 Details");
        B2 ob = new B2();
        
        System.out.println("================================"+"\n"+"Enter B3 Details");
        B3 obj = new B3();
        
        ob1.display();
       
        ob.display();
        
        obj.display();
		

	}

}
