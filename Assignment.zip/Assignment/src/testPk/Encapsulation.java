package testPk;
class Encapsulation1
{
	private String Email;
	private int Age;
	
	public String getEmail()
	{
		return Email;
	}
	public void setEmail(String email)
	{
		Email=email;
	}
	public int getAge()
	{
		return Age;
	}
	public void setAge(int age)
	{
		Age=age;
	}
}
public class Encapsulation {

	public static void main(String[] args) {
		Encapsulation1 ee=new Encapsulation1();
		ee.setEmail("Oytie@yahoo.com");
		System.out.println("Email:"+ee.getEmail());
		ee.setAge(50);
		System.out.println("Age:"+ee.getAge());
		
		

	}

}
